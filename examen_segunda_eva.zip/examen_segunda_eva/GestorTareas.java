/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.examen_segunda_eva;

/**
 *
 * @author alejandro.esteban1
 */
import java.util.ArrayList;
import java.util.Scanner;

public class GestorTareas {
    // Lista para almacenar las tareas pendientes
    private static ArrayList<String> tareas = new ArrayList<>();
    // Scanner para leer la entrada del usuario
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        int opcion;
        do {
            mostrarMenu();
            while (!scanner.hasNextInt()) {
                System.out.println("Por favor, ingrese un numero valido.");
                scanner.next();
            }
            opcion = scanner.nextInt();
            scanner.nextLine(); // Limpiar buffer
            
            switch (opcion) {
                case 1:
                    agregarTarea(); // Agrega una nueva tarea
                    break;
                case 2:
                    eliminarTarea(); // Elimina una tarea por índice
                    break;
                case 3:
                    consultarTarea(); // Consulta una tarea por índice
                    break;
                case 4:
                    mostrarTareas(); // Muestra todas las tareas pendientes
                    break;
                case 5:
                    System.out.println("Gracias por usar el Gestor de Tareas Pendientes.");
                    break;
                default:
                    System.out.println("Opcion no valida. Intente nuevamente.");
            }
        } while (opcion != 5);
    }

    // Muestra el menú de opciones al usuario
    private static void mostrarMenu() {
        System.out.println("\nBienvenido al Gestor de Tareas Pendientes.");
        System.out.println("1. Agregar Tarea");
        System.out.println("2. Eliminar Tarea");
        System.out.println("3. Consultar Tarea");
        System.out.println("4. Mostrar Todas las Tareas");
        System.out.println("5. Salir");
        System.out.print("Seleccione una opcion: ");
    }

    // Permite al usuario agregar una nueva tarea a la lista
    private static void agregarTarea() {
        String tarea = "";
        while (tarea.isEmpty() || tarea.matches("\\d+")) {
            System.out.print("Ingrese la descripción de la tarea (no puede ser solo un número): ");
            tarea = scanner.nextLine().trim();
            if (tarea.isEmpty()) {
                System.out.println("La tarea no puede estar vacia.");
            } else if (tarea.matches("\\d+")) {
                System.out.println("La tarea no puede ser solo un numero.");
                tarea = ""; // Reiniciar para volver a solicitar entrada
            }
        }
        tareas.add(tarea);
        System.out.println("Tarea agregada correctamente.");
    }

    // Permite al usuario eliminar una tarea específica por índice
    private static void eliminarTarea() {
        int indice = -1;
        while (true) {
            System.out.print("Ingrese el indice de la tarea a eliminar: ");
            if (scanner.hasNextInt()) {
                indice = scanner.nextInt();
                scanner.nextLine(); // Limpiar buffer
                if (indice > 0 && indice <= tareas.size()) {
                    tareas.remove(indice - 1);
                    System.out.println("Tarea eliminada correctamente.");
                    break;
                } else {
                    System.out.println("Indice fuera de rango.");
                }
            } else {
                System.out.println("Entrada no valida. Debe ingresar un numero valido.");
                scanner.next(); // Limpiar entrada errónea
            }
        }
    }

    // Permite al usuario consultar una tarea específica por índice
    private static void consultarTarea() {
        int indice = -1;
        while (true) {
            System.out.print("Ingrese el indice de la tarea a consultar: ");
            if (scanner.hasNextInt()) {
                indice = scanner.nextInt();
                scanner.nextLine(); // Limpiar buffer
                if (indice > 0 && indice <= tareas.size()) {
                    System.out.println("Tarea " + indice + ": " + tareas.get(indice - 1));
                    break;
                } else {
                    System.out.println("Indice fuera de rango.");
                }
            } else {
                System.out.println("Entrada no válida. Debe ingresar un numero valido.");
                scanner.next(); // Limpiar entrada errónea
            }
        }
    }

    // Muestra todas las tareas almacenadas en la lista
    private static void mostrarTareas() {
        if (tareas.isEmpty()) {
            System.out.println("No hay tareas pendientes.");
        } else {
            System.out.println("Tareas Pendientes:");
            for (int i = 0; i < tareas.size(); i++) {
                System.out.println((i + 1) + ". " + tareas.get(i));
            }
        }
    }
}